# 中国经济离线练习

在解压目录运行（Python 3，无第三方依赖）：

```sh
python3 tools/econ_lab.py --as-of 2025-06-30
python3 tools/econ_lab.py --as-of 2025-12-31
python3 -m unittest discover -s tests -v
```

数据版本与教学假设见 data/README.md。教程：https://fangpings.github.io/cn-econ/43-data-workflow.html
